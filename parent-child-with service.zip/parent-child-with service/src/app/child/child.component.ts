import { Component, OnInit, Input, Output, EventEmitter  } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

 @Input() childMessage: string;

 message = "Hola Mundo!"

  @Output() messageEvent = new EventEmitter<string>();

  buttonStatus = false;

  constructor(private data: DataService) { }


  sendMessage() {
    alert('hi');
    this.messageEvent.emit(this.message)
  }

  ngOnInit() {
    this.data.currentMessage.subscribe(message => this.message = message)
  }

  newMessage() {
    this.data.changeMessage("Hello from Sibling");
    console.log('test');
    this.buttonStatus = true;
  }

}
