import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {FormControl, FormGroup} from '@angular/forms';

import { DataService } from '../dataservice';
import { Country } from '../country';
import { State } from '../state';
import { Observable} from 'rxjs';

import { filter } from 'rxjs/operators';
import { UtilityService } from "src/app/utility.service";


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss'],
  providers: [DataService]
})
export class FormComponent implements OnInit {

  selectedCountry:Country = new Country(0, 'India'); 
  countries: Country[];
  states: State[];
  filter: any;


  states1 = [
    {name: 'Arizona', abbrev: 'AZ'},
    {name: 'California', abbrev: 'CA'},
    {name: 'Colorado', abbrev: 'CO'},
    {name: 'New York', abbrev: 'NY'},
    {name: 'Pennsylvania', abbrev: 'PA'},
  ];
 
  form = new FormGroup({
   // state: new FormControl(this.states[3]),
  });

  heroes = ['Windstrom', 'Bombasto', 'Magneta', 'Tornado']
public data : any;  
public list : any;

  constructor(private httpService: HttpClient, private _dataService: DataService, private utility: UtilityService) {
    this.countries = this._dataService.getCountries();
   }
  onSelect(countryid) {
    this.states = this._dataService.getStates().filter((item)=> item.countryid == countryid);
  }
  
employees : string [];

  ngOnInit() {
  //   this.data = [
  //   {'firstname': 'John', 'lastname': 'Smith', 'sex': 'Male', 'city': 'Newyork'},
  //   {'firstname': 'July', 'lastname':'Thomas', 'sex': 'Female', 'city': 'Plano'},
  //    {'firstname': 'Austin', 'lastname': 'Max', 'sex': 'Male', 'city': 'Los Angles'},
  //   {'firstname': 'Brain', 'Lara':'Thomas', 'sex': 'Male', 'city': 'England'},
  //    {'firstname': 'Jennifer', 'lastname': 'Chiristina', 'sex': 'Female', 'city': 'Sydney'},
  //   {'firstname': 'White', 'lastname':'Alex', 'sex': 'Male', 'city': 'Plano'},
  //    {'firstname': 'Dharshan', 'lastname': 'Kumar', 'sex': 'Male', 'city': 'Bangalore'},
  //   {'firstname': 'Sunil', 'lastname':'Kumar', 'sex': 'Male', 'city': 'Delhi'},
  //    {'firstname': 'Aryan', 'lastname': 'Sarat', 'sex': 'Male', 'city': 'Mumbai'},
  //   {'firstname': 'Rahul', 'lastname':'Panday', 'sex': 'Male', 'city': 'Pune'},
  //    {'firstname': 'Shanker', 'lastname': 'Lal', 'sex': 'Male', 'city': 'Chennai'},
  //   {'firstname': 'Suju', 'lastname':'Kurivilla', 'sex': 'Male', 'city': 'Plano'}
  // ]


  this.httpService.get('./assets/employees.json').subscribe(
      data => {
        this.data = data as string [];	 // FILL THE ARRAY WITH DATA.
        console.log(this.data[0]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );

    this.httpService.get('./assets/list.json').subscribe(
      list=> {
        this.list = list as string [];
        console.log(this.list[0]);
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
    
  }

  btndisable() {
    this.utility.sendMessage('message');
  }

}
