import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from "@angular/router";
import { UtilityService } from "src/app/utility.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  registerForm: FormGroup;
    submitted = false;

  constructor(private formBuilder: FormBuilder, private router: Router, private utility: UtilityService) { }

  ngOnInit() {
     this.registerForm = this.formBuilder.group({
            firstName: ['', [Validators.required, Validators.minLength(3)]],
            lastName: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(6)]]
        });
        this.utility.disable.subscribe( data => {
          console.log(data);
        });
  }

  get f() { return this.registerForm.controls; }

  onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) { 
            return;
        }
else{
  this.router.navigate(['/form']);
}
        alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
    }

}
