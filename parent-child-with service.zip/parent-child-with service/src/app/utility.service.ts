import { Injectable } from '@angular/core';
import { Subject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  constructor() { }

  private subject = new Subject<any>();
  disable = this.subject.asObservable();

    sendMessage(message: string) {
        this.subject.next(message);
    }
}
